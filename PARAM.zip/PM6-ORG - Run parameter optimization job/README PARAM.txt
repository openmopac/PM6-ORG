Suggested procedure for getting PARAM to work:

Compile PARAM to make an executable.

All files used by PARAM are in this folder, this includes the lists of reference data files:

Core.txt
Clashes.txt
All intermolecular interaction sets
Specific properties.txt
Repulsive interactions.txt

and all the reference data files, these are in the folders:

Core
Clashes
Intermolecular interactions
Repulsive interactions
Specific properties

Instructions on PARAM are in:

http://openmopac.net/param manual/

These files have not been updated in a long time, so some links might be broken.

As a first step, run PM6-ORG.dat. The parameter optimization will restart where the previous run, i.e., the one in this folder, left off.  Because this run was the last parameter optimization for PM6-ORG, the parameters and results should not change significantly.




