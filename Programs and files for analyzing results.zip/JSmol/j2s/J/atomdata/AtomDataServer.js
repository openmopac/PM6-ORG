Clazz.declarePackage ("J.atomdata");
Clazz.declareInterface (J.atomdata, "AtomDataServer");
