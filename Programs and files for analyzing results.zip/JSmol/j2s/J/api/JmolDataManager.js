Clazz.declarePackage ("J.api");
c$ = Clazz.declareInterface (J.api, "JmolDataManager");
Clazz.defineStatics (c$,
"DATA_TYPE_LAST", -2,
"DATA_TYPE_UNKNOWN", -1,
"DATA_TYPE_STRING", 0,
"DATA_TYPE_AF", 1,
"DATA_TYPE_AFF", 2,
"DATA_TYPE_AFFF", 3,
"DATA_LABEL", 0,
"DATA_VALUE", 1,
"DATA_SELECTION", 2,
"DATA_TYPE", 3,
"DATA_SAVE_IN_STATE", 4);
