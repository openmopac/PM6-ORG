vti_encoding:SR|utf8-nl
vti_timelastmodified:TR|03 Mar 2016 19:26:09 -0000
vti_extenderversion:SR|12.0.0.0
vti_author:SR|K20\\James
vti_modifiedby:SR|K20\\James
vti_timecreated:TR|03 Mar 2016 19:26:09 -0000
vti_cacheddtm:TX|03 Mar 2016 19:26:09 -0000
vti_filesize:IR|88
vti_backlinkinfo:VX|
